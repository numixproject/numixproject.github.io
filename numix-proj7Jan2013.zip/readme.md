
#A Basic Laravel Boilerplate

### Contains 
* JQuery
* JQueryUI
* Bootstrap 3
* Font-awesome 4
* alertify
* data table
* chart.js
* mousetrap.js

=======

* PHPExcel
* Laravel-generator



