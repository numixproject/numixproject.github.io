@extends("master")
@section("content")
	<div class="row">
		<h2>halelujah</h2>
	</div>
@stop