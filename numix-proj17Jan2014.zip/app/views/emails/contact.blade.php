
<h3>query  from {{$from}}</h3>
<hr>
<span>{{$msg}}</span>
<br>
<em>sent on {{date('y-m-d h:i:s')}} from {{Request::getClientIp()}}</em>
